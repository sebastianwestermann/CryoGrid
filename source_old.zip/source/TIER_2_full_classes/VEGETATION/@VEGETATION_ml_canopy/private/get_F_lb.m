function ground = get_heatFlux_lb(ground, forcing)

ground.TEMP.F_lb = forcing.PARA.heatFlux_lb;