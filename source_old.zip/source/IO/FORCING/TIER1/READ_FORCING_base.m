classdef READ_FORCING_base < matlab.mixin.Copyable
    
    properties
        
    end
    
    methods
        
    end    
    
end
