function result = issingle(obj)
import yaml.*;
result = all(size(obj) == 1) ;
end
